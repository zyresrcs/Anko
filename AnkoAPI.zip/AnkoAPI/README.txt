 ______     __  __     ______     ______
/\___  \   /\ \_\ \   /\  == \   /\  ___\
\/_/  /__  \ \____ \  \ \  __<   \ \  __\
  /\_____\  \/\_____\  \ \_\ \_\  \ \_____\
  \/_____/   \/_____/   \/_/ /_/   \/_____/
 ______   ______     ______       __     ______     ______     ______   ______    
/\  == \ /\  == \   /\  __ \     /\ \   /\  ___\   /\  ___\   /\__  _\ /\  ___\   
\ \  _-/ \ \  __<   \ \ \/\ \   _\_\ \  \ \  __\   \ \ \____  \/_/\ \/ \ \___  \  
 \ \_\    \ \_\ \_\  \ \_____\ /\_____\  \ \_____\  \ \_____\    \ \_\  \/\_____\ 
  \/_/     \/_/ /_/   \/_____/ \/_____/   \/_____/   \/_____/     \/_/   \/_____/ 
                                                                                  
===========================================================
                       AnkoAPI v1.0
===========================================================

Hello, thank you for using AnkoAPI.

Yes, this is v1, but in the next update I will add
a Roblox console output system similar to Volt or Potassium.

For now, this is the first public version.
I have included all required files so you only need to add
them to your project.


Step 1:

In your project, go to the References section.

Right click and select:

Add Reference

Then go to:

Browse

and select my API:

AnkoAPI.dll


After that, you need to move the "bin" folder next to your
project's .exe file.

This is required for the API to work correctly.


Step 2:

My API includes the following functions:

AnkoAPI.ExecuteScript

AnkoAPI.AttachAPI

AnkoAPI.KillRoblox

AnkoAPI.IsRobloxOpen

AnkoAPI.IsAttached


I will let you explore what each function does and how you
can use them, because I got lazy continuing to write ;)

===========================================================
                         CONTACT
===========================================================

Discord
l8z4

Server
https://discord.gg/cs7Jhuqaxd


===========================================================
                      OTHER LINKS
===========================================================

GitHub
https://github.com/zyresrcs


guns.lol
https://guns.lol/l8z4


Roblox
https://www.roblox.com/users/10701483053/profile


===========================================================
                     MORE PROJECTS
===========================================================

More projects:

https://zyresrcs.github.io/dexdr-wame/