﻿namespace AnkoAPIUiTempletate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.executebutton = new System.Windows.Forms.Button();
            this.clearbutton = new System.Windows.Forms.Button();
            this.openbutton = new System.Windows.Forms.Button();
            this.savebutton = new System.Windows.Forms.Button();
            this.attachbutton = new System.Windows.Forms.Button();
            this.killrobloxbutton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.richTextBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 450);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.killrobloxbutton);
            this.panel2.Controls.Add(this.attachbutton);
            this.panel2.Controls.Add(this.savebutton);
            this.panel2.Controls.Add(this.openbutton);
            this.panel2.Controls.Add(this.clearbutton);
            this.panel2.Controls.Add(this.executebutton);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 410);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 40);
            this.panel2.TabIndex = 3;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.richTextBox1.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(800, 409);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "print(\'Hello World!\')";
            // 
            // executebutton
            // 
            this.executebutton.Dock = System.Windows.Forms.DockStyle.Left;
            this.executebutton.Location = new System.Drawing.Point(0, 0);
            this.executebutton.Name = "executebutton";
            this.executebutton.Size = new System.Drawing.Size(75, 40);
            this.executebutton.TabIndex = 0;
            this.executebutton.Text = "EXECUTE";
            this.executebutton.UseVisualStyleBackColor = true;
            this.executebutton.Click += new System.EventHandler(this.executebutton_Click);
            // 
            // clearbutton
            // 
            this.clearbutton.Dock = System.Windows.Forms.DockStyle.Left;
            this.clearbutton.Location = new System.Drawing.Point(75, 0);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(75, 40);
            this.clearbutton.TabIndex = 1;
            this.clearbutton.Text = "CLEAR";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // openbutton
            // 
            this.openbutton.Dock = System.Windows.Forms.DockStyle.Left;
            this.openbutton.Location = new System.Drawing.Point(150, 0);
            this.openbutton.Name = "openbutton";
            this.openbutton.Size = new System.Drawing.Size(75, 40);
            this.openbutton.TabIndex = 2;
            this.openbutton.Text = "OPEN";
            this.openbutton.UseVisualStyleBackColor = true;
            this.openbutton.Click += new System.EventHandler(this.openbutton_Click);
            // 
            // savebutton
            // 
            this.savebutton.Dock = System.Windows.Forms.DockStyle.Left;
            this.savebutton.Location = new System.Drawing.Point(225, 0);
            this.savebutton.Name = "savebutton";
            this.savebutton.Size = new System.Drawing.Size(75, 40);
            this.savebutton.TabIndex = 3;
            this.savebutton.Text = "SAVE";
            this.savebutton.UseVisualStyleBackColor = true;
            this.savebutton.Click += new System.EventHandler(this.savebutton_Click);
            // 
            // attachbutton
            // 
            this.attachbutton.Dock = System.Windows.Forms.DockStyle.Right;
            this.attachbutton.Location = new System.Drawing.Point(725, 0);
            this.attachbutton.Name = "attachbutton";
            this.attachbutton.Size = new System.Drawing.Size(75, 40);
            this.attachbutton.TabIndex = 4;
            this.attachbutton.Text = "ATTACH";
            this.attachbutton.UseVisualStyleBackColor = true;
            this.attachbutton.Click += new System.EventHandler(this.attachbutton_Click);
            // 
            // killrobloxbutton
            // 
            this.killrobloxbutton.Dock = System.Windows.Forms.DockStyle.Left;
            this.killrobloxbutton.Location = new System.Drawing.Point(300, 0);
            this.killrobloxbutton.Name = "killrobloxbutton";
            this.killrobloxbutton.Size = new System.Drawing.Size(75, 40);
            this.killrobloxbutton.TabIndex = 5;
            this.killrobloxbutton.Text = "KILL ROBLOX";
            this.killrobloxbutton.UseVisualStyleBackColor = true;
            this.killrobloxbutton.Click += new System.EventHandler(this.killrobloxbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "AnkoAPI Templetate";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button attachbutton;
        private System.Windows.Forms.Button savebutton;
        private System.Windows.Forms.Button openbutton;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Button executebutton;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button killrobloxbutton;
    }
}

