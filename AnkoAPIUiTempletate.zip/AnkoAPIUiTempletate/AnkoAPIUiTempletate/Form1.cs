﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace AnkoAPIUiTempletate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // API Buttons

        private void executebutton_Click(object sender, EventArgs e)
        {
            AnkoAPI.ExecuteScript(richTextBox1.Text);
        }
        private void attachbutton_Click(object sender, EventArgs e)
        {
            AnkoAPI.AttachAPI();
        }

        private void killrobloxbutton_Click(object sender, EventArgs e)
        {
            AnkoAPI.KillRoblox();
        }

        // Basic Buttons

        private void clearbutton_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void openbutton_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Filter = "Lua (*.lua)|*.lua|Text (*.txt)|*.txt|All (*.*)|*.*";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.Text = File.ReadAllText(dlg.FileName);
                }
            }
        }

        private void savebutton_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "Lua (*.lua)|*.lua|Text (*.txt)|*.txt";
                dlg.FileName = "script.lua";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(dlg.FileName, richTextBox1.Text);
                }
            }
        }
    }
}
