 ______     __  __     ______     ______
/\___  \   /\ \_\ \   /\  == \   /\  ___\
\/_/  /__  \ \____ \  \ \  __<   \ \  __\
  /\_____\  \/\_____\  \ \_\ \_\  \ \_____\
  \/_____/   \/_____/   \/_/ /_/   \/_____/
 ______   ______     ______       __     ______     ______     ______   ______    
/\  == \ /\  == \   /\  __ \     /\ \   /\  ___\   /\  ___\   /\__  _\ /\  ___\   
\ \  _-/ \ \  __<   \ \ \/\ \   _\_\ \  \ \  __\   \ \ \____  \/_/\ \/ \ \___  \  
 \ \_\    \ \_\ \_\  \ \_____\ /\_____\  \ \_____\  \ \_____\    \ \_\  \/\_____\ 
  \/_/     \/_/ /_/   \/_____/ \/_____/   \/_____/   \/_____/     \/_/   \/_____/ 
                                                                                  
===========================================================
                     AnkoAPI v1.0
             Open Source API & UI Template
===========================================================

Hello, thank you for downloading the AnkoAPI UI Template.

In this source, I have included the most basic way you can
use my API in your project.

Everything is already set up so you can integrate it into
your project in a more visual way.

===========================================================
                        CONTACT
===========================================================

Discord
l8z4

Server
https://discord.gg/cs7Jhuqaxd

===========================================================
                      OTHER LINKS
===========================================================

GitHub
https://github.com/zyresrcs

guns.lol
https://guns.lol/l8z4

Roblox
https://www.roblox.com/users/10701483053/profile

===========================================================
                     MORE PROJECTS
===========================================================

You can find more of my projects here:

https://zyresrcs.github.io/dexdr-wame/