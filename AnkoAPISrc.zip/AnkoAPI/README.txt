 ______     __  __     ______     ______
/\___  \   /\ \_\ \   /\  == \   /\  ___\
\/_/  /__  \ \____ \  \ \  __<   \ \  __\
  /\_____\  \/\_____\  \ \_\ \_\  \ \_____\
  \/_____/   \/_____/   \/_/ /_/   \/_____/
 ______   ______     ______       __     ______     ______     ______   ______    
/\  == \ /\  == \   /\  __ \     /\ \   /\  ___\   /\  ___\   /\__  _\ /\  ___\   
\ \  _-/ \ \  __<   \ \ \/\ \   _\_\ \  \ \  __\   \ \ \____  \/_/\ \/ \ \___  \  
 \ \_\    \ \_\ \_\  \ \_____\ /\_____\  \ \_____\  \ \_____\    \ \_\  \/\_____\ 
  \/_/     \/_/ /_/   \/_____/ \/_____/   \/_____/   \/_____/     \/_/   \/_____/ 
                                                                                  
===========================================================
                       AnkoAPI v1.0
                Open Source Execution API
===========================================================

Hello, and thank you for downloading AnkoAPI!

AnkoAPI is a lightweight and open-source API designed to provide
simple integration between applications and Xeno.

The goal of this project is to give developers a clean and easy
way to initialize, attach, execute scripts, and manage Roblox
clients through a simple C# interface.

You are free to modify, improve, and integrate this source code
into your own projects.

===========================================================
                         CREDITS
===========================================================

AnkoAPI is powered by Xeno.

All execution technology and the native DLL belong to the
Xeno developers.

Website
https://www.xeno.now/

Discord
https://discord.gg/xe-no

Special thanks to the Xeno team for making this possible.

===========================================================
                         CONTACT
===========================================================

Discord
l8z4

Server
https://discord.gg/cs7Jhuqaxd


===========================================================
                      OTHER LINKS
===========================================================

GitHub
https://github.com/zyresrcs


guns.lol
https://guns.lol/l8z4


Roblox
https://www.roblox.com/users/10701483053/profile


===========================================================
                     MORE PROJECTS
===========================================================

More projects:

https://zyresrcs.github.io/dexdr-wame/


===========================================================
                         LICENSE
===========================================================

This project is provided as open source.

Please keep original credits when using or modifying
significant parts of the source code.

===========================================================

Thank you for using AnkoAPI.

Have fun coding!


                         - l8z4